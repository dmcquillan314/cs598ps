function main()
    clear all; close all;
    
    l5_25;
    l5_37;
    l5_39;
    l5_52;
    l6_22;
    l6_32;
    l6_45;
    l6_51;
    l6_52;
    l6_54;
    l7_36;
    l7_56;
    l7_68_70;

    extra_credit;
end

