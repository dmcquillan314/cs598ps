function [ v ] = vec( X )
%VEC vectorizes a given matrix

    v = X(:);
    
end

