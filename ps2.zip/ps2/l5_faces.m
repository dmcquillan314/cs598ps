function [ F ] = l5_faces()

    F = load('faces.mat');

end

